# valuatio-data

Automated nightly stock data fetcher for the Valuatio app. Runs on GitHub Actions
(free), pulls live + fundamental data from Financial Modeling Prep, commits
results to `data/master.csv` and `data/master.json`.

## Why this exists

Google Apps Script's `UrlFetchApp` is limited to 20,000 calls/day per Google
account, which is fine for small portfolios but quickly hits the wall on
larger universes (5,000+ tickers). This project moves the bulk data pull
out of Google Sheets entirely. GitHub Actions has no equivalent daily quota
and runs the script for free on a schedule.

The Valuatio app reads the resulting `master.csv` directly from a raw GitHub
URL, no Google Sheets in the loop.

---

## Setup (one-time, ~10 minutes)

### 1. Create the repo

1. Sign in to https://github.com (or sign up — free)
2. Click the `+` → **New repository**
3. Name: `valuatio-data` (or anything you want)
4. Visibility: **Public** (required for free Actions on personal accounts;
   private repos work too but eat your free Actions minutes faster)
5. **Create repository**

### 2. Upload these files

Easiest way: from the new empty repo page, click **uploading an existing file**.

Drag all of these in, preserving the folder structure:

```
valuatio-data/
├── .github/
│   └── workflows/
│       └── fetch_data.yml
├── data/
│   └── tickers.txt
├── fetch_data.py
└── README.md
```

Commit message: "Initial setup". Click **Commit changes**.

### 3. Add your FMP API key as a secret

1. In the repo, click **Settings** (top right)
2. Left sidebar: **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Name: `FMP_API_KEY`
5. Value: your FMP API key from https://financialmodelingprep.com/dashboard
6. **Add secret**

The key is now available to the workflow as `${{ secrets.FMP_API_KEY }}`.
GitHub encrypts it — even repo collaborators can't read the value back.

### 4. Customize your ticker list

Edit `data/tickers.txt`. One ticker per line. Lines starting with `#` are comments.

Recommended: start with 50-100 tickers, run the workflow once to confirm it
works, then add the rest.

### 5. Run the workflow

1. Click the **Actions** tab in your repo
2. Left sidebar: **Fetch Stock Data**
3. Click **Run workflow** → green **Run workflow** button
4. Wait ~30-60 seconds. You should see a green checkmark.
5. Click into the run to see the logs — it should report how many tickers got data

### 6. Check the output

After the workflow finishes, your `data/master.csv` and `data/master.json` will
be populated. The "raw" URL of `master.csv` looks like:

```
https://raw.githubusercontent.com/YOUR-USERNAME/valuatio-data/main/data/master.csv
```

That's what the Valuatio app uses as a data source.

---

## How it works

### Schedule

Workflow runs automatically:
- **11am ET weekdays** — midday update
- **5pm ET weekdays** — after-market-close update

You can also trigger it manually anytime from the Actions tab.

### API usage

Per run, for ~1000 tickers:
- **10 batch-quote calls** (100 tickers each) — pulls live prices, change %, volume, market cap, P/E, EPS, 52-week range, etc.
- **~10-30 profile calls** — pulls company info (sector, industry, CEO, description, logo, website). Only refreshes tickers whose profiles are older than 30 days. Once a ticker has a profile, it sticks.

Total: ~40 calls per run × 2 runs/day = **80 calls/day**, well under FMP's
250/day free limit.

### What's in `master.csv`

40 columns matching the Valuatio app's expected schema:

| Field | Source |
|---|---|
| ticker, name | profile |
| price, marketcap, volume, volumeavg | quote |
| priceopen, low, high, close, change, changepct, closeyest, date | quote |
| high52, low52, beta, shares, pe, eps | quote + profile |
| sector, industry, description, exchange, ceo, country, ipodate | profile |
| isEtf, isFund, isActive, currency, employees | profile |
| web_url, image, city, state, phone, address | profile |
| fetched_at, profile_fetched_at | metadata |

### Forcing a full refresh

The default schedule preserves stable profile fields (sector, CEO, description)
across runs to save quota. To force a refresh of ALL profiles:

1. Actions tab → Fetch Stock Data → **Run workflow**
2. Check **"Force full profile refresh for all tickers"**
3. Run

Note: this uses N profile calls where N is your ticker count. 250+ tickers
will hit the daily limit on a full refresh — only do this occasionally.

---

## Hooking it up to the Valuatio app

In the Valuatio app's **Data Sources** panel, add the raw CSV URL as one of your
sheet URLs:

```
https://raw.githubusercontent.com/YOUR-USERNAME/valuatio-data/main/data/master.csv
```

The app will parse it just like a Google Sheets CSV. Combined with your
Google Sheets URLs, it will sift through both sources and prefer non-N/A
values per field.

---

## Costs

- **GitHub**: free for public repos (2,000 free Actions minutes/month — this
  workflow uses ~2 minutes per run × 40 runs/month = 80 minutes)
- **FMP**: free tier (250 calls/day) — this script uses ~80
- **Total**: $0/month

---

## Troubleshooting

### "FMP_API_KEY not set" in the logs

You skipped step 3. Go to repo Settings → Secrets and variables → Actions,
add the secret `FMP_API_KEY`.

### Many tickers show empty prices

Either:
- Some tickers in `data/tickers.txt` are invalid or delisted — FMP returns
  nothing for them
- You hit the FMP 250/day quota — wait until midnight UTC and rerun
- Specific tickers may require FMP paid plan (rare for major equities)

### "Permission to write to the repo denied"

In repo Settings → Actions → General, scroll to "Workflow permissions" and
select **"Read and write permissions"**. Save.

### Workflow doesn't run on schedule

GitHub Actions cron is best-effort and can be delayed by 10-30 minutes during
high traffic. If it skips entirely for >24 hours, push any change to the repo
to wake it up.

### Want to track different fields?

Edit `OUTPUT_COLUMNS` in `fetch_data.py` and add the mapping in `build_row()`.
The FMP profile/quote endpoints return many fields not all of which we map.
See https://site.financialmodelingprep.com/developer/docs for the full list.
